/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin processor.

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include "Parameters.h"
#include "DSP/PhaserProcessor.h"
#include "DSP/LFO.h"
#include "DSP/TopBoost.h"
#include "DSP/EnvelopeDetector.h"
#include "DSP/SubOctave.h"
#include "DSP/RingMod.h"
#include "DSP/SustainFuzz.h"
#include "DSP/Growl.h"


//==============================================================================
/**
*/
class HiFlyerAudioProcessor  : public juce::AudioProcessor
{
public:
    //==============================================================================
    HiFlyerAudioProcessor();
    ~HiFlyerAudioProcessor() override;

    //==============================================================================
    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;

   #ifndef JucePlugin_PreferredChannelConfigurations
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
   #endif

    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    //==============================================================================
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override;

    //==============================================================================
    const juce::String getName() const override;

    bool acceptsMidi() const override;
    bool producesMidi() const override;
    bool isMidiEffect() const override;
    double getTailLengthSeconds() const override;

    //==============================================================================
    int getNumPrograms() override;
    int getCurrentProgram() override;
    void setCurrentProgram (int index) override;
    const juce::String getProgramName (int index) override;
    void changeProgramName (int index, const juce::String& newName) override;

    //==============================================================================
    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;
    
    juce::AudioProcessorValueTreeState apvts { *this, nullptr, "Parameters", Parameters::createParameterLayout()};

private:
    
    Parameters params;
    
    static constexpr int maxChannels = 2;
    TopBoost topBoost[maxChannels];
    LFO lfo;
    PhaserProcessor phaser[maxChannels];
    EnvelopeDetector envelopeDetector[maxChannels];
    SubOctave subOct[maxChannels];
    RingMod ringMod[maxChannels];
    SustainFuzz sustainFuzz[maxChannels];
    Growl growl[maxChannels];
    
    int dbgCounter = 0;
    bool lfoAttackTrigger = false;
    bool lfoDecayTrigger = false;
    
    //==============================================================================
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (HiFlyerAudioProcessor)
};
