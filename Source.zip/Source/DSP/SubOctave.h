/*
  ==============================================================================

    SubOctave.h
    Created: 23 Mar 2026 4:07:20pm
    Author:  Marcello Cirelli

  ==============================================================================
*/

#pragma once
#include <juce_dsp/juce_dsp.h>

class SubOctave
{
public:
    void prepare (const juce::dsp::ProcessSpec& spec);
    void reset();

    // buzz=false: raw divided square wave.
    // buzz=true: hardware-style low-pass after the divider.
    float processSample (float input, bool buzz) noexcept;

private:
    static constexpr float kInputHighpassMs = 18.0f;
    static constexpr float kTrackingLowpassMs = 0.22f;
    static constexpr float kEnvelopeMs = 8.0f;
    static constexpr float kThresholdRatio = 0.38f;
    static constexpr float kThresholdFloor = 0.0025f;
    static constexpr float kThresholdCeiling = 0.18f;
    static constexpr float kHysteresisRatio = 0.55f;

    static constexpr float kMinInputHz = 22.0f;
    static constexpr float kMaxInputHz = 4500.0f;

    static constexpr float kEdgeBlankingMs = 0.16f;
    static constexpr float kOutputHoldMs = 85.0f;
    static constexpr float kOutputSlewMs = 0.08f;
    static constexpr float kBuzzLowpassMs = 0.65f;

    static float msToCoeff (double sr, float ms) noexcept;
    static int msToSamples (double sr, float ms) noexcept;

    void updateComparator (float x) noexcept;
    void setFirstFlipFlop (bool newState) noexcept;

    double sampleRate = 44100.0;

    float highpassState = 0.0f;
    float lowpassState = 0.0f;
    float envelope = 0.0f;
    float buzzFilter = 0.0f;
    float outputSlew = 0.0f;

    bool positiveComparator = false;
    bool negativeComparator = false;
    bool ff1 = false;
    bool ff2 = false;

    int samplesSinceEdge = 1000000;
    int samplesSinceValidEdge = 1000000;
    int blankingSamples = 1;
    int minPeriodSamples = 1;
    int maxPeriodSamples = 1000000;
    int holdSamples = 1;

    float highpassCoeff = 0.0f;
    float lowpassCoeff = 0.0f;
    float envCoeff = 0.0f;
    float buzzCoeff = 0.0f;
    float slewCoeff = 0.0f;
};
