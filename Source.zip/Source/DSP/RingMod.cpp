/*
  ==============================================================================

    RingMod.cpp
    Created: 24 Mar 2026 11:01:59am
    Author:  Marcello Cirelli

  ==============================================================================
*/

#include "RingMod.h"
#include <cmath>

void RingMod::prepare(const juce::dsp::ProcessSpec &spec)
{
    reset();
}

void RingMod::reset()
{
    
}

float RingMod::processSample(float input, float carrier, float amount) noexcept
{
    const float modulated = input * carrier;
    return input + (modulated - input) * amount;
}
