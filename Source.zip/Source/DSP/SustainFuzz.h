/*
  ==============================================================================

    SustainFuzz.h
    Created: 24 Mar 2026 1:04:24pm
    Author:  Marcello Cirelli

  ==============================================================================
*/

#pragma once
#include <juce_dsp/juce_dsp.h>

class SustainFuzz
{
    public:
    void prepare (const juce::dsp::ProcessSpec& spec);
    void reset();
    
    float processSample (float input, float fuzzLevel) noexcept;
    
    private:
    double sampleRate = 0.0;
    static constexpr float kLpfHz = 329.0f;
    static constexpr float kBaseDrive = 18.0f;
    static constexpr float kExtraDrive = 30.0f;
    static constexpr float kCeiling = 1.0f;
    static constexpr float kOutputTrim = 0.85f;

    float lpfCoeff = 0.0f;
    float lpfState = 0.0f;
};
