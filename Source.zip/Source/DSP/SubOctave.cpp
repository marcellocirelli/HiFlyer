/*
  ==============================================================================

    SubOctave.cpp
    Created: 23 Mar 2026 4:07:20pm
    Author:  Marcello Cirelli

  ==============================================================================
*/

#include "SubOctave.h"
#include <algorithm>
#include <cmath>

float SubOctave::msToCoeff (double sr, float ms) noexcept
{
    ms = std::max (0.001f, ms);
    return 1.0f - std::exp (-1.0f / (static_cast<float> (sr) * ms * 0.001f));
}

int SubOctave::msToSamples (double sr, float ms) noexcept
{
    return std::max (1, static_cast<int> (std::round (sr * ms * 0.001)));
}

void SubOctave::prepare (const juce::dsp::ProcessSpec& spec)
{
    sampleRate = spec.sampleRate > 0.0 ? spec.sampleRate : 44100.0;

    highpassCoeff = msToCoeff (sampleRate, kInputHighpassMs);
    lowpassCoeff  = msToCoeff (sampleRate, kTrackingLowpassMs);
    envCoeff      = msToCoeff (sampleRate, kEnvelopeMs);
    buzzCoeff     = msToCoeff (sampleRate, kBuzzLowpassMs);
    slewCoeff     = msToCoeff (sampleRate, kOutputSlewMs);

    blankingSamples = msToSamples (sampleRate, kEdgeBlankingMs);
    holdSamples = msToSamples (sampleRate, kOutputHoldMs);
    minPeriodSamples = std::max (1, static_cast<int> (sampleRate / kMaxInputHz));
    maxPeriodSamples = std::max (1, static_cast<int> (sampleRate / kMinInputHz));

    reset();
}

void SubOctave::reset()
{
    highpassState = 0.0f;
    lowpassState = 0.0f;
    envelope = 0.0f;
    buzzFilter = 0.0f;
    outputSlew = 0.0f;

    positiveComparator = false;
    negativeComparator = false;
    ff1 = false;
    ff2 = false;

    samplesSinceEdge = maxPeriodSamples;
    samplesSinceValidEdge = holdSamples + 1;
}

void SubOctave::setFirstFlipFlop (bool newState) noexcept
{
    if (ff1 != newState)
    {
        const int period = samplesSinceEdge;
        samplesSinceEdge = 0;

        if (period >= minPeriodSamples && period <= maxPeriodSamples)
        {
            const bool rising = (! ff1 && newState);
            ff1 = newState;

            // Stage two divides the cleaned first-stage square wave by two.
            if (rising)
                ff2 = ! ff2;

            samplesSinceValidEdge = 0;
        }
        else
        {
            ff1 = newState;
        }
    }
}

void SubOctave::updateComparator (float x) noexcept
{
    const float threshold = juce::jlimit (kThresholdFloor, kThresholdCeiling,
                                          envelope * kThresholdRatio);
    const float lowThreshold = threshold * kHysteresisRatio;

    if (samplesSinceEdge < blankingSamples)
        return;

    if (! positiveComparator && x >= threshold)
    {
        positiveComparator = true;
        negativeComparator = false;
        setFirstFlipFlop (false); // clear
    }
    else if (positiveComparator && x < lowThreshold)
    {
        positiveComparator = false;
    }

    if (! negativeComparator && x <= -threshold)
    {
        negativeComparator = true;
        positiveComparator = false;
        setFirstFlipFlop (true); // set
    }
    else if (negativeComparator && x > -lowThreshold)
    {
        negativeComparator = false;
    }
}

float SubOctave::processSample (float input, bool buzz) noexcept
{
    // Remove DC/very slow movement, then lightly smooth the signal feeding the
    // virtual comparators. This keeps the divider feel but avoids chatter.
    highpassState += highpassCoeff * (input - highpassState);
    const float highpassed = input - highpassState;

    lowpassState += lowpassCoeff * (highpassed - lowpassState);
    const float tracked = lowpassState;

    const float rectified = std::abs (tracked);
    envelope += envCoeff * (rectified - envelope);

    ++samplesSinceEdge;
    ++samplesSinceValidEdge;

    updateComparator (tracked);

    const float target = (samplesSinceValidEdge <= holdSamples)
                       ? (ff2 ? 1.0f : -1.0f) * envelope
                       : 0.0f;

    outputSlew += slewCoeff * (target - outputSlew);

    if (buzz)
    {
        buzzFilter += buzzCoeff * (outputSlew - buzzFilter);
        return buzzFilter;
    }

    return outputSlew;
}
