/*
  ==============================================================================

    SustainFuzz.cpp
    Created: 24 Mar 2026 1:04:24pm
    Author:  Marcello Cirelli

  ==============================================================================
*/

#include "SustainFuzz.h"
#include <cmath>
#include <algorithm>

void SustainFuzz::prepare (const juce::dsp::ProcessSpec& spec)
{
    sampleRate = spec.sampleRate > 0.0 ? spec.sampleRate : 44100.0;

    const float w = juce::MathConstants<float>::twoPi * kLpfHz / static_cast<float> (sampleRate);
    lpfCoeff = w / (1.0f + w);

    reset();
}

void SustainFuzz::reset()
{
    lpfState = 0.0f;
}

float SustainFuzz::processSample (float input, float fuzzLevel) noexcept
{
    // fuzzLevel should mostly control external wet/dry mix, but a small internal
    // drive dependency helps the fuzz feel more alive at higher settings without
    // reintroducing the old rise-envelope gain coupling.
    const float amount = juce::jlimit (0.0f, 1.0f, fuzzLevel);
    const float drive = kBaseDrive + amount * kExtraDrive;

    const float amplified = input * drive;

    // Soft saturation into a hard-ish ceiling avoids the clipping ticks/chatter
    // that became more noticeable once attack/rise is event-shaped upstream.
    const float saturated = std::tanh (amplified);
    const float clipped = juce::jlimit (-kCeiling, kCeiling, saturated);

    // Hardware-style low-pass coloration around 329 Hz.
    lpfState += lpfCoeff * (clipped - lpfState);

    return lpfState * kOutputTrim;
}
